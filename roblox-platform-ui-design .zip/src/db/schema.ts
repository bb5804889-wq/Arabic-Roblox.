import { pgTable, text, timestamp, boolean, integer } from "drizzle-orm/pg-core";

export const apiSettings = pgTable("api_settings", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  siteApiKey: text("site_api_key"),
  novaAiApiKey: text("nova_ai_api_key"),
  // Delta auth URL (the platorelay link)
  deltaAuthUrl: text("delta_auth_url"),
  // Cached delta key (FREE_xxx) and its expiry
  deltaCachedKey: text("delta_cached_key"),
  deltaKeyExpiry: timestamp("delta_key_expiry", { mode: "date" }),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const scripts = pgTable("scripts", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  title: text("title").notNull(),
  description: text("description"),
  code: text("code"),
  category: text("category").notNull().default("general"),
  author: text("author").default("مجهول"),
  featured: boolean("featured").default(false),
  downloads: integer("downloads").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  role: text("role").notNull(), // 'user' | 'assistant'
  content: text("content").notNull(),
  attachments: text("attachments"), // JSON string
  createdAt: timestamp("created_at").defaultNow(),
});

export const users = pgTable("users", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  username: text("username").notNull().unique(),
  displayName: text("display_name"),
  avatar: text("avatar"),
  platform: text("platform"), // ios | android | windows
  createdAt: timestamp("created_at").defaultNow(),
});
