"use client";

import { useState, useEffect, useRef } from "react";
import {
  Bell, Globe, Link2, Shield, Zap, Users, MessageCircle,
  BookOpen, FilePlus, Code2, Key, Trophy, Award, Bot,
  User, LogIn, BarChart3, HelpCircle, Send, Mic,
  ChevronLeft, Download, Star, Eye, Plus, Search,
  X, Check, Lock, Cpu, Rocket, Gamepad2, Smartphone,
  Monitor, Apple, Terminal, FileText, Sparkles, Heart,
  ExternalLink, Volume2, Settings, Crown, TrendingUp,
  Copy, RefreshCw, Clock, AlertCircle
} from "lucide-react";

// ============ TYPE DEFINITIONS ============
interface ScriptItem {
  id: string; title: string; description?: string; code?: string;
  category: string; author?: string; featured?: boolean; downloads?: number;
}

interface ChatMsg {
  role: "user" | "assistant"; content: string;
}

interface DeltaKeyInfo {
  hasKey: boolean; key?: string; expiresAt?: string;
  remainingTime?: string; sourceUrl?: string; refreshed?: boolean;
  message?: string;
}

// ============ MAIN APP COMPONENT ============
export default function ArabHackApp() {
  const [lang, setLang] = useState<"ar" | "en">("ar");
  const [showApiModal, setShowApiModal] = useState(false);
  const [showDeltaModal, setShowDeltaModal] = useState(false);
  const [showNovaChat, setShowNovaChat] = useState(false);
  const [showStatsModal, setShowStatsModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showScriptsModal, setShowScriptsModal] = useState(false);

  // API settings
  const [apiPassword, setApiPassword] = useState("");
  const [apiAuthenticated, setApiAuthenticated] = useState(false);
  const [siteApiKey, setSiteApiKey] = useState("");
  const [novaAiApiKey, setNovaAiApiKey] = useState("");
  const [deltaAuthUrl, setDeltaAuthUrl] = useState("");

  // Delta key
  const [deltaKeyInfo, setDeltaKeyInfo] = useState<DeltaKeyInfo | null>(null);
  const [deltaLoading, setDeltaLoading] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState<string | null>(null);
  const [keyCopied, setKeyCopied] = useState(false);

  // Scripts
  const [scripts, setScripts] = useState<ScriptItem[]>([]);

  // Chat
  const [chatMessages, setChatMessages] = useState<ChatMsg[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [codeMode, setCodeMode] = useState(false);

  // Stats
  const [stats, setStats] = useState<Record<string, number>>({});

  // Notification
  const [notification, setNotification] = useState<string | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => { fetchScripts(); fetchStats(); }, []);
  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [chatMessages]);

  const fetchScripts = async () => {
    try {
      const res = await fetch("/api/scripts");
      setScripts(await res.json());
    } catch { /* defaults */ }
  };

  const fetchStats = async () => {
    try {
      const res = await fetch("/api/stats");
      setStats(await res.json());
    } catch { /* ignore */ }
  };

  const fetchDeltaKey = async () => {
    setDeltaLoading(true);
    try {
      const res = await fetch("/api/delta");
      const data = await res.json();
      setDeltaKeyInfo(data);
    } catch {
      setDeltaKeyInfo({ hasKey: false, message: "خطأ في الاتصال" });
    } finally {
      setDeltaLoading(false);
    }
  };

  const notify = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setKeyCopied(true);
      setTimeout(() => setKeyCopied(false), 2000);
      notify("✅ تم نسخ المفتاح!");
    } catch {
      notify("❌ فشل النسخ");
    }
  };

  // API auth
  const handleApiAuth = () => {
    if (apiPassword === "AH-7392-XQ") {
      setApiAuthenticated(true);
    } else {
      notify("❌ كلمة السر غير صحيحة!");
    }
  };

  const handleSaveApi = async () => {
    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          password: "AH-7392-XQ",
          siteApiKey: siteApiKey || undefined,
          novaAiApiKey: novaAiApiKey || undefined,
          deltaAuthUrl: deltaAuthUrl || undefined,
        }),
      });
      const data = await res.json();
      if (data.success) {
        notify("✅ تم حفظ إعدادات API بنجاح! النظام كامل يعمل الآن.");
        setShowApiModal(false);
        setApiAuthenticated(false);
      } else {
        notify("❌ " + (data.error || "خطأ في الحفظ"));
      }
    } catch {
      notify("❌ خطأ في الاتصال");
    }
  };

  // Chat
  const handleSendMessage = async () => {
    if (!chatInput.trim()) return;
    const userMsg = chatInput.trim();
    setChatInput("");
    setChatMessages(prev => [...prev, { role: "user", content: userMsg }]);
    setIsChatLoading(true);
    try {
      const res = await fetch("/api/nova", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMsg }),
      });
      const data = await res.json();
      setChatMessages(prev => [...prev, { role: "assistant", content: data.content || "عذراً، لم أتمكن من الرد." }]);
    } catch {
      setChatMessages(prev => [...prev, { role: "assistant", content: "❌ خطأ في الاتصال بالخادم" }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Delta download
  const handleDeltaDownload = async (platform: string) => {
    setSelectedPlatform(platform);
    setDeltaLoading(true);
    try {
      const res = await fetch("/api/delta", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ platform }),
      });
      const data = await res.json();
      if (data.error) {
        notify("⚠️ " + data.error);
      } else if (data.success) {
        setDeltaKeyInfo({
          hasKey: true,
          key: data.deltaKey,
          remainingTime: "24 ساعة 0 دقيقة",
        });
        notify(`✅ تم جلب مفتاح Delta لـ ${platform}! المفتاح: ${data.deltaKey?.substring(0, 15)}...`);
      }
    } catch {
      notify("❌ خطأ في التحميل");
    } finally {
      setDeltaLoading(false);
    }
  };

  const featuredScript = scripts.find(s => s.featured) || {
    id: "0", title: "سكربت سرعة خارقة", description: "زيادة سرعة اللاعب في أي لعبة", category: "roblox", downloads: 1520
  };

  // ============ RENDER ============
  return (
    <div className="min-h-screen bg-[#0a0a1a] text-white overflow-x-hidden">
      {/* Notification */}
      {notification && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] bg-purple-600/90 backdrop-blur-md text-white px-6 py-3 rounded-xl shadow-2xl border border-purple-400/50 text-sm max-w-md text-center">
          {notification}
        </div>
      )}

      {/* ========== TOP HEADER BAR ========== */}
      <header className="sticky top-0 z-50 bg-[#0a0a1a]/95 backdrop-blur-xl border-b border-purple-900/30">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowLoginModal(true)}
              className="flex items-center gap-2 bg-purple-600/20 hover:bg-purple-600/40 border border-purple-500/30 px-4 py-2 rounded-full text-sm transition-all hover:scale-105"
            >
              <Link2 size={16} />
              <span>{lang === "ar" ? "اربط حسابك" : "Link Account"}</span>
            </button>
            <button
              onClick={() => setLang(lang === "ar" ? "en" : "ar")}
              className="flex items-center gap-1 bg-white/10 hover:bg-white/20 px-3 py-2 rounded-lg text-sm transition-all"
            >
              <Globe size={14} />
              {lang === "ar" ? "EN" : "عربي"}
            </button>
            <button className="relative bg-white/10 hover:bg-white/20 p-2 rounded-lg transition-all">
              <Bell size={18} />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[10px] flex items-center justify-center">3</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center text-lg font-bold animate-glow">
              ⚡
            </div>
            <div className="text-center">
              <h1 className="text-lg font-bold bg-gradient-to-l from-purple-400 to-blue-400 bg-clip-text text-transparent">
                عرب هاك
              </h1>
              <p className="text-[10px] text-gray-400">ccraft.space</p>
            </div>
          </div>

          <button
            onClick={() => setShowApiModal(true)}
            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 p-2 rounded-lg transition-all"
          >
            <Settings size={18} />
          </button>
        </div>
      </header>

      {/* ========== HERO SECTION ========== */}
      <section className="relative py-12 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-transparent to-transparent" />
        <div className="absolute top-10 right-1/4 w-72 h-72 bg-purple-600/10 rounded-full blur-3xl" />
        <div className="absolute top-20 left-1/4 w-56 h-56 bg-blue-600/10 rounded-full blur-3xl" />

        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <div className="mx-auto w-28 h-28 bg-gradient-to-br from-purple-600 via-blue-600 to-cyan-500 rounded-full flex items-center justify-center mb-6 animate-glow shadow-2xl shadow-purple-500/30">
            <span className="text-4xl">⚡</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-black mb-2 bg-gradient-to-l from-purple-300 via-blue-300 to-cyan-300 bg-clip-text text-transparent">
            CCRAFT SPACE
          </h2>
          <p className="text-gray-400 text-lg mb-8">منصة سكربتات ROBLOX العربية</p>

          <div className="flex flex-wrap items-center justify-center gap-4 mb-6">
            <button
              onClick={() => { setShowDeltaModal(true); fetchDeltaKey(); }}
              className="flex items-center gap-2 bg-gradient-to-l from-green-600/30 to-emerald-600/30 hover:from-green-600/50 hover:to-emerald-600/50 border border-green-500/40 px-6 py-3 rounded-full text-sm transition-all hover:scale-105 animate-pulse-border"
            >
              <Zap size={18} className="text-green-400" />
              <span>عمل مفتاح arab hack</span>
              <span className="text-green-400 text-xs">Δ</span>
            </button>
            <button
              onClick={() => { setShowStatsModal(true); fetchStats(); }}
              className="flex items-center gap-2 bg-gradient-to-l from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 px-8 py-3 rounded-xl text-sm font-bold transition-all hover:scale-105 shadow-lg shadow-purple-500/30"
            >
              <BarChart3 size={18} />
              <span>عرض الإحصائيات المباشرة</span>
            </button>
          </div>
        </div>
      </section>

      {/* ========== GRID CATEGORIES ========== */}
      <main className="max-w-7xl mx-auto px-4 pb-8 space-y-6">

        <SectionTitle icon={<Shield size={20} />} title="الأساسيات" />
        <div className="grid grid-cols-3 gap-3">
          <CategoryCard icon={<Code2 size={22} />} label="السكربتات" color="purple" onClick={() => setShowScriptsModal(true)} />
          <CategoryCard icon={<FilePlus size={22} />} label="نشر سكربت" color="blue" />
          <CategoryCard icon={<Shield size={22} />} label="أمان سكربتات" color="cyan" />
          <CategoryCard icon={<Users size={22} />} label="المجتمع" color="green" />
          <CategoryCard icon={<Send size={22} />} label="تلجرام" color="sky" />
          <CategoryCard icon={<MessageCircle size={22} />} label="شات" color="pink" />
        </div>

        {/* Arab Hack Card */}
        <button
          onClick={() => { setShowDeltaModal(true); fetchDeltaKey(); }}
          className="w-full flex items-center gap-4 bg-gradient-to-l from-green-900/40 to-emerald-900/40 hover:from-green-900/60 hover:to-emerald-900/60 border border-green-500/30 rounded-2xl p-4 transition-all group"
        >
          <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
            <Zap size={24} className="text-green-400" />
          </div>
          <div className="flex-1 text-right">
            <h3 className="font-bold text-green-300">arab hack</h3>
            <p className="text-xs text-green-400/70">
              {deltaKeyInfo?.hasKey
                ? `مفتاح فعّال - ${deltaKeyInfo.remainingTime}`
                : "مفتاح Delta - الوصول لجميع السكربتات والأدوات"}
            </p>
          </div>
          <span className="text-2xl text-green-400 font-bold">Δ</span>
        </button>

        <SectionTitle icon={<BookOpen size={20} />} title="الشروحات" />
        <div className="grid grid-cols-2 gap-3">
          <CategoryCard icon={<BookOpen size={22} />} label="الشروحات" color="amber" badge="جديد" />
          <CategoryCard icon={<FilePlus size={22} />} label="نشر شرح" color="orange" badge="جديد" />
        </div>

        <SectionTitle icon={<Cpu size={20} />} title="أدوات مطورين" />
        <div className="grid grid-cols-2 gap-3">
          <CategoryCard icon={<Code2 size={22} />} label="محرر الأكواد" color="violet" subtitle="</>" />
          <CategoryCard icon={<Key size={22} />} label="واجهة API" color="indigo" onClick={() => setShowApiModal(true)} />
        </div>

        <SectionTitle icon={<Users size={20} />} title="المجتمع" />
        <div className="grid grid-cols-2 gap-3">
          <CategoryCard icon={<Trophy size={22} />} label="ليدربورد" color="yellow" />
          <CategoryCard icon={<Award size={22} />} label="بادجات" color="rose" />
        </div>

        <SectionTitle icon={<Sparkles size={20} />} title="أدوات" />
        <button
          onClick={() => setShowNovaChat(true)}
          className="w-full flex items-center gap-4 bg-gradient-to-l from-purple-900/40 to-indigo-900/40 hover:from-purple-900/60 hover:to-indigo-900/60 border border-purple-500/30 rounded-2xl p-4 transition-all group animate-glow"
        >
          <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
            <Bot size={24} className="text-purple-300" />
          </div>
          <div className="flex-1 text-right">
            <h3 className="font-bold text-purple-200">NOVA AI</h3>
            <p className="text-xs text-purple-400/70">المساعد الذكي - مساعدة فورية في الكود</p>
          </div>
          <div className="flex items-center gap-1 text-green-400 text-xs">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            متصل
          </div>
        </button>

        <SectionTitle icon={<User size={20} />} title="حسابك" />
        <div className="grid grid-cols-2 gap-3">
          <CategoryCard icon={<User size={22} />} label="بروفايلي" color="teal" />
          <CategoryCard icon={<LogIn size={22} />} label="تسجيل الدخول" color="blue" onClick={() => setShowLoginModal(true)} />
        </div>

        <SectionTitle icon={<HelpCircle size={20} />} title="معلومات ودعم" />
        <div className="grid grid-cols-3 gap-3">
          <CategoryCard icon={<BarChart3 size={20} />} label="إحصائيات" color="purple" onClick={() => { setShowStatsModal(true); fetchStats(); }} />
          <CategoryCard icon={<HelpCircle size={20} />} label="الدعم" color="blue" />
          <CategoryCard icon={<Send size={20} />} label="تلجرام" color="sky" />
        </div>

        {/* Featured Script */}
        <div className="bg-gradient-to-l from-purple-900/50 to-indigo-900/50 border border-purple-500/30 rounded-2xl p-5 shimmer-bg">
          <div className="flex items-center gap-3 mb-3">
            <Star size={20} className="text-yellow-400" />
            <h3 className="font-bold text-purple-200">سكربت اليوم المميز</h3>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-lg font-semibold">{featuredScript.title}</p>
              <p className="text-sm text-gray-400">{featuredScript.description}</p>
              <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                <span className="flex items-center gap-1"><Eye size={12} /> {featuredScript.downloads} تحميل</span>
                <span className="flex items-center gap-1"><Heart size={12} /> 84</span>
              </div>
            </div>
            <button className="bg-purple-600 hover:bg-purple-500 px-4 py-2 rounded-lg text-sm transition-all">عرض السكربت</button>
          </div>
        </div>

        {/* Latest Scripts */}
        <div className="bg-gradient-to-l from-purple-900/30 to-indigo-900/30 border border-purple-500/20 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <TrendingUp size={20} className="text-purple-400" />
              <h3 className="font-bold text-purple-200">أحدث السكربتات</h3>
            </div>
            <button onClick={() => setShowScriptsModal(true)} className="text-sm text-purple-400 hover:text-purple-300 flex items-center gap-1">
              عرض الكل <ChevronLeft size={14} />
            </button>
          </div>
          <div className="space-y-2">
            {(scripts.length > 0 ? scripts : [
              { id: "1", title: "سكربت سرعة خارقة", author: "عرب هاك", downloads: 1520, category: "roblox" },
              { id: "2", title: "سكربت طيران لا محدود", author: "عرب هاك", downloads: 2340, category: "roblox" },
              { id: "3", title: "سكربت ESP وول هاك", author: "عرب هاك", downloads: 890, category: "roblox" },
            ]).slice(0, 3).map((s, i) => (
              <div key={s.id || i} className="flex items-center gap-3 bg-white/5 rounded-xl p-3 hover:bg-white/10 transition-all cursor-pointer">
                <div className="w-8 h-8 bg-purple-500/20 rounded-lg flex items-center justify-center text-purple-400"><Code2 size={16} /></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{s.title}</p>
                  <p className="text-xs text-gray-500">{s.author} • {s.downloads} تحميل</p>
                </div>
                <span className="text-xs text-purple-400 bg-purple-500/20 px-2 py-1 rounded">{s.category}</span>
              </div>
            ))}
          </div>
        </div>

        <SectionTitle icon={<Rocket size={20} />} title="إجراءات سريعة" />
        <div className="space-y-2">
          <QuickAction icon={<FilePlus size={18} />} label="انشر سكربت الآن" color="purple" />
          <QuickAction icon={<Download size={18} />} label="تصفح تطبيقات APK" color="blue" />
          <QuickAction icon={<User size={18} />} label="غيّر صورة البروفايل" color="cyan" />
          <QuickAction icon={<Bot size={18} />} label="اسأل NOVA AI" color="indigo" subtitle="مساعدة فورية في الكود" onClick={() => setShowNovaChat(true)} />
        </div>
      </main>

      {/* ========== NOVA AI CHAT ========== */}
      {showNovaChat && (
        <div className="fixed inset-0 z-50 bg-[#0a0a1a] flex flex-col">
          <div className="bg-[#111128] border-b border-purple-900/30 p-4">
            <div className="flex items-center justify-between mb-3">
              <button onClick={() => setShowNovaChat(false)} className="bg-white/10 hover:bg-white/20 p-2 rounded-lg transition-all"><X size={20} /></button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-xl flex items-center justify-center"><Bot size={20} /></div>
                <div>
                  <h3 className="font-bold">NOVA AI</h3>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="flex items-center gap-1 text-green-400"><span className="w-2 h-2 bg-green-400 rounded-full" />متصل</span>
                    <span className="text-gray-500">gemini-2.0-flash-lite</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setCodeMode(!codeMode)}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs transition-all ${codeMode ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30" : "bg-white/10 text-gray-400"}`}
              >
                <Terminal size={14} /> وضع الأكواد
              </button>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2 text-xs" dir="ltr">
              {["لعبة تجنب عقبات", "عالم فضائي", "سكربت جافاسكريبت", "فيديوهات"].map((tab) => (
                <span key={tab} className="whitespace-nowrap bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-full cursor-pointer transition-all">{tab}</span>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {chatMessages.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                <Bot size={48} className="mx-auto mb-4 text-purple-500/50" />
                <p className="text-lg mb-2">مرحباً! أنا NOVA AI 👋</p>
                <p className="text-sm">اسألني عن سكربتات Roblox، أكواد، أو أي شيء!</p>
              </div>
            )}
            {chatMessages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === "user" ? "justify-start" : "justify-end"}`}>
                <div className={`max-w-[80%] rounded-2xl p-3 text-sm ${msg.role === "user" ? "bg-purple-600/30 border border-purple-500/20 rounded-br-sm" : "bg-gray-800/80 border border-gray-700/50 rounded-bl-sm"}`}>
                  {msg.role === "assistant" && (
                    <div className="flex items-center gap-1 mb-1 text-xs text-purple-400"><Bot size={12} /> NOVA AI</div>
                  )}
                  <p className="whitespace-pre-wrap" dir="auto">{msg.content}</p>
                </div>
              </div>
            ))}
            {isChatLoading && (
              <div className="flex justify-end">
                <div className="bg-gray-800/80 rounded-2xl rounded-bl-sm p-3 text-sm text-gray-400">
                  <span className="flex items-center gap-2">
                    <Bot size={14} /> جاري التفكير
                    <span className="flex gap-1">
                      <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                      <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                      <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                    </span>
                  </span>
                </div>
              </div>
            )}
            <div className="bg-[#1a1a3e] border border-purple-500/20 rounded-xl p-3 max-w-[80%]">
              <div className="flex items-center gap-2 mb-2"><FileText size={16} className="text-purple-400" /><span className="text-sm font-medium">README.md</span></div>
              <p className="text-xs text-gray-400 mb-2">ملف تعريفي للمشروع</p>
              <button className="text-xs text-purple-400 hover:text-purple-300 flex items-center gap-1"><ExternalLink size={12} /> فتح الملف</button>
            </div>
            <div ref={chatEndRef} />
          </div>

          <div className="bg-[#111128] border-t border-purple-900/30 p-4">
            <div className="flex items-center gap-2">
              <button className="bg-white/10 hover:bg-white/20 p-2.5 rounded-xl transition-all"><Mic size={18} className="text-gray-400" /></button>
              <div className="flex-1">
                <input
                  type="text" value={chatInput} onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                  placeholder="اكتب لـ Nova..."
                  className="w-full bg-white/10 border border-purple-500/20 rounded-xl px-4 py-2.5 text-sm placeholder:text-gray-500 focus:outline-none focus:border-purple-500/50 transition-all"
                  dir="rtl"
                />
              </div>
              <button
                onClick={handleSendMessage} disabled={isChatLoading || !chatInput.trim()}
                className="bg-purple-600 hover:bg-purple-500 disabled:opacity-50 disabled:hover:bg-purple-600 p-2.5 rounded-xl transition-all"
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========== API SETTINGS MODAL ========== */}
      {showApiModal && (
        <Modal onClose={() => { setShowApiModal(false); setApiAuthenticated(false); }} title="إعدادات API">
          {!apiAuthenticated ? (
            <div className="space-y-4">
              <div className="text-center mb-4">
                <div className="w-16 h-16 bg-purple-500/20 rounded-2xl flex items-center justify-center mx-auto mb-3"><Lock size={28} className="text-purple-400" /></div>
                <p className="text-gray-400">يتطلب كلمة سر للدخول</p>
              </div>
              <input type="password" value={apiPassword} onChange={(e) => setApiPassword(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleApiAuth()}
                placeholder="أدخل كلمة السر..."
                className="w-full bg-white/10 border border-purple-500/20 rounded-xl px-4 py-3 text-sm placeholder:text-gray-500 focus:outline-none focus:border-purple-500/50"
                dir="ltr"
              />
              <button onClick={handleApiAuth} className="w-full bg-purple-600 hover:bg-purple-500 py-3 rounded-xl font-bold transition-all">دخول</button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-green-400 mb-4"><Check size={18} /><span className="text-sm">تم التحقق بنجاح</span></div>

              <div>
                <label className="text-sm text-gray-400 mb-1 block">مفتاح API للموقع</label>
                <input type="text" value={siteApiKey} onChange={(e) => setSiteApiKey(e.target.value)}
                  placeholder="أدخل مفتاح API..."
                  className="w-full bg-white/10 border border-purple-500/20 rounded-xl px-4 py-3 text-sm placeholder:text-gray-500 focus:outline-none focus:border-purple-500/50"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="text-sm text-gray-400 mb-1 block">مفتاح API لـ Nova AI (Gemini)</label>
                <input type="text" value={novaAiApiKey} onChange={(e) => setNovaAiApiKey(e.target.value)}
                  placeholder="AIza..."
                  className="w-full bg-white/10 border border-purple-500/20 rounded-xl px-4 py-3 text-sm placeholder:text-gray-500 focus:outline-none focus:border-purple-500/50"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="text-sm text-gray-400 mb-1 flex items-center gap-1">
                  <Zap size={14} className="text-green-400" />
                  رابط مفتاح Delta (platorelay)
                </label>
                <input type="text" value={deltaAuthUrl} onChange={(e) => setDeltaAuthUrl(e.target.value)}
                  placeholder="https://auth.platorelay.com/a?d=..."
                  className="w-full bg-white/10 border border-green-500/20 rounded-xl px-4 py-3 text-sm placeholder:text-gray-500 focus:outline-none focus:border-green-500/50 font-mono"
                  dir="ltr"
                />
                <p className="text-[11px] text-gray-600 mt-1">
                  الرابط يبدأ بـ https://auth.platorelay.com/a?d= ويجلب مفتاح FREE_... كل 24 ساعة
                </p>
              </div>

              <div className="bg-purple-900/30 border border-purple-500/20 rounded-xl p-3">
                <p className="text-xs text-purple-300">
                  ⚡ عند وضع API، سيعمل على كل الموقع: الذكاء الاصطناعي، بحث السكربتات، مفتاح Delta. المفتاح يتجدد تلقائياً كل 24 ساعة.
                </p>
              </div>

              <button onClick={handleSaveApi}
                className="w-full bg-green-600 hover:bg-green-500 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2"
              >
                <Check size={18} /> حفظ الإعدادات
              </button>
            </div>
          )}
        </Modal>
      )}

      {/* ========== DELTA HACK MODAL ========== */}
      {showDeltaModal && (
        <Modal onClose={() => setShowDeltaModal(false)} title="Delta Hack - مفتاح عرب هاك">
          <div className="space-y-4">
            <div className="text-center mb-2">
              <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-3 animate-glow">
                <Zap size={36} className="text-white" />
              </div>
              <h3 className="text-xl font-bold text-green-300">Delta Hack</h3>
              <p className="text-sm text-gray-400">مفتاح عرب هاك - يجدد تلقائياً كل 24 ساعة</p>
            </div>

            {/* Current Key Status */}
            {deltaLoading ? (
              <div className="bg-white/5 rounded-xl p-4 text-center">
                <div className="flex items-center justify-center gap-2 text-green-400">
                  <RefreshCw size={18} className="animate-spin" />
                  <span className="text-sm">جاري جلب المفتاح...</span>
                </div>
              </div>
            ) : deltaKeyInfo?.hasKey && deltaKeyInfo.key ? (
              <div className="bg-green-900/30 border border-green-500/30 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2 text-green-400">
                  <Check size={16} />
                  <span className="text-sm font-bold">مفتاح فعّال</span>
                </div>
                {/* Key display */}
                <div className="bg-black/30 rounded-lg p-3 mb-3 font-mono text-xs break-all" dir="ltr">
                  <span className="text-green-300">{deltaKeyInfo.key.substring(0, 5)}</span>
                  <span className="text-green-500">{deltaKeyInfo.key.substring(5)}</span>
                </div>
                {/* Copy button */}
                <button
                  onClick={() => copyToClipboard(deltaKeyInfo.key!)}
                  className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-500 py-2 rounded-lg text-sm transition-all mb-2"
                >
                  {keyCopied ? <Check size={16} /> : <Copy size={16} />}
                  {keyCopied ? "تم النسخ!" : "نسخ المفتاح"}
                </button>
                {/* Expiry info */}
                {deltaKeyInfo.remainingTime && (
                  <div className="flex items-center gap-2 text-xs text-gray-400 mt-2">
                    <Clock size={12} />
                    <span>ينتهي بعد: {deltaKeyInfo.remainingTime}</span>
                  </div>
                )}
                {deltaKeyInfo.refreshed && (
                  <p className="text-xs text-green-400 mt-1">🔄 تم تجديد المفتاح</p>
                )}
              </div>
            ) : deltaKeyInfo?.message ? (
              <div className="bg-yellow-900/30 border border-yellow-500/30 rounded-xl p-4">
                <div className="flex items-center gap-2 text-yellow-400 mb-1">
                  <AlertCircle size={16} />
                  <span className="text-sm">{deltaKeyInfo.message}</span>
                </div>
                {!deltaKeyInfo.hasKey && (
                  <button
                    onClick={() => setShowApiModal(true)}
                    className="text-xs text-yellow-300 hover:text-yellow-200 flex items-center gap-1 mt-2"
                  >
                    <Settings size={12} /> اذهب لإعدادات API
                  </button>
                )}
              </div>
            ) : null}

            {/* Refresh Key Button */}
            <button
              onClick={fetchDeltaKey}
              disabled={deltaLoading}
              className="w-full flex items-center justify-center gap-2 bg-white/10 hover:bg-white/15 border border-green-500/20 py-2.5 rounded-xl text-sm transition-all text-green-400"
            >
              <RefreshCw size={16} className={deltaLoading ? "animate-spin" : ""} />
              تجديد المفتاح
            </button>

            {/* Platform Download */}
            <div className="border-t border-white/10 pt-4">
              <p className="text-sm text-gray-400 mb-3 text-center">اختر منصتك لتحميل أحدث نسخة</p>
              <div className="space-y-2">
                {[
                  { id: "ios", icon: <Apple size={22} className="text-gray-300" />, label: "iOS", sub: "iPhone / iPad", bg: "bg-gray-500/20" },
                  { id: "android", icon: <Smartphone size={22} className="text-green-300" />, label: "Android", sub: "هواتف وأجهزة لوحية", bg: "bg-green-500/20" },
                  { id: "windows", icon: <Monitor size={22} className="text-blue-300" />, label: "Windows", sub: "كمبيوتر محمول ومكتبي", bg: "bg-blue-500/20" },
                ].map(p => (
                  <button
                    key={p.id}
                    onClick={() => handleDeltaDownload(p.id)}
                    disabled={deltaLoading}
                    className="w-full flex items-center gap-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-3 transition-all group disabled:opacity-50"
                  >
                    <div className={`w-10 h-10 ${p.bg} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      {p.icon}
                    </div>
                    <div className="flex-1 text-right">
                      <p className="text-sm font-bold">{p.label}</p>
                      <p className="text-[11px] text-gray-500">{p.sub}</p>
                    </div>
                    <Download size={18} className="text-green-400" />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </Modal>
      )}

      {/* ========== STATS MODAL ========== */}
      {showStatsModal && (
        <Modal onClose={() => setShowStatsModal(false)} title="الإحصائيات المباشرة">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <StatCard label="إجمالي السكربتات" value={stats.totalScripts || 6} icon={<Code2 size={20} />} color="purple" />
              <StatCard label="المستخدمين" value={stats.totalUsers || 1250} icon={<Users size={20} />} color="blue" />
              <StatCard label="التحميلات" value={stats.totalDownloads || 8120} icon={<Download size={20} />} color="cyan" />
              <StatCard label="متصل الآن" value={stats.onlineUsers || 34} icon={<Volume2 size={20} />} color="green" />
              <StatCard label="السكربتات المميزة" value={stats.featuredScripts || 3} icon={<Star size={20} />} color="yellow" />
              <StatCard label="رسائل NOVA" value={stats.totalMessages || 0} icon={<Bot size={20} />} color="indigo" />
            </div>
            <div className="bg-white/5 rounded-xl p-4 text-center">
              <p className="text-xs text-gray-500">🔄 يتم تحديث الإحصائيات تلقائياً</p>
            </div>
          </div>
        </Modal>
      )}

      {/* ========== LOGIN MODAL ========== */}
      {showLoginModal && (
        <Modal onClose={() => setShowLoginModal(false)} title="تسجيل الدخول">
          <div className="space-y-4">
            <div className="text-center mb-4">
              <div className="w-16 h-16 bg-purple-500/20 rounded-2xl flex items-center justify-center mx-auto mb-3"><Crown size={28} className="text-purple-400" /></div>
              <p className="text-gray-400">اربط حسابك للاستمتاع بجميع المزايا</p>
            </div>
            <input type="text" placeholder="اسم المستخدم" className="w-full bg-white/10 border border-purple-500/20 rounded-xl px-4 py-3 text-sm placeholder:text-gray-500 focus:outline-none focus:border-purple-500/50" />
            <input type="password" placeholder="كلمة المرور" className="w-full bg-white/10 border border-purple-500/20 rounded-xl px-4 py-3 text-sm placeholder:text-gray-500 focus:outline-none focus:border-purple-500/50" />
            <button className="w-full bg-purple-600 hover:bg-purple-500 py-3 rounded-xl font-bold transition-all">تسجيل الدخول</button>
            <p className="text-xs text-center text-gray-500">ليس لديك حساب؟ <span className="text-purple-400 cursor-pointer">سجل الآن</span></p>
          </div>
        </Modal>
      )}

      {/* ========== SCRIPTS MODAL ========== */}
      {showScriptsModal && (
        <Modal onClose={() => setShowScriptsModal(false)} title="السكربتات">
          <div className="space-y-3">
            <div className="relative mb-4">
              <Search size={16} className="absolute right-3 top-3.5 text-gray-500" />
              <input type="text" placeholder="ابحث عن سكربت..." className="w-full bg-white/10 border border-purple-500/20 rounded-xl pr-10 pl-4 py-3 text-sm placeholder:text-gray-500 focus:outline-none focus:border-purple-500/50" />
            </div>
            {(scripts.length > 0 ? scripts : [
              { id: "1", title: "سكربت سرعة خارقة", description: "زيادة سرعة اللاعب", category: "roblox", downloads: 1520, author: "عرب هاك" },
              { id: "2", title: "سكربت طيران لا محدود", description: "تفعيل الطيران", category: "roblox", downloads: 2340, author: "عرب هاك" },
              { id: "3", title: "سكربت ESP وول هاك", description: "رؤية عبر الجدران", category: "roblox", downloads: 890, author: "عرب هاك" },
              { id: "4", title: "سكربت أموال لا محدود", description: "أموال لا محدودة", category: "roblox", downloads: 3500, author: "عرب هاك" },
              { id: "5", title: "سكربت تيليبورتر", description: "انتقال فوري", category: "roblox", downloads: 670, author: "عرب هاك" },
            ]).map((s, i) => (
              <div key={s.id || i} className="bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl p-4 transition-all cursor-pointer">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-medium">{s.title}</h4>
                  <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded">{s.category}</span>
                </div>
                <p className="text-xs text-gray-500">{s.description}</p>
                <div className="flex items-center gap-4 mt-2 text-xs text-gray-600">
                  <span>{s.author}</span>
                  <span className="flex items-center gap-1"><Download size={10} /> {s.downloads}</span>
                </div>
              </div>
            ))}
          </div>
        </Modal>
      )}

      {/* ========== FOOTER ========== */}
      <footer className="bg-[#080818] border-t border-purple-900/20 py-6 mt-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-gray-500 mb-4">
            {["السكربتات", "APK Mods", "الليدربورد", "الإحصائيات", "API", "الدعم", "الخصوصية"].map((link) => (
              <button key={link} onClick={() => link === "API" ? setShowApiModal(true) : undefined} className="hover:text-purple-400 transition-colors">{link}</button>
            ))}
          </div>
          <div className="flex items-center justify-center gap-3 text-gray-600">
            <span className="w-8 h-8 bg-white/5 rounded-lg flex items-center justify-center hover:bg-white/10 cursor-pointer transition-all"><Send size={14} /></span>
            <span className="w-8 h-8 bg-white/5 rounded-lg flex items-center justify-center hover:bg-white/10 cursor-pointer transition-all"><MessageCircle size={14} /></span>
            <span className="w-8 h-8 bg-white/5 rounded-lg flex items-center justify-center hover:bg-white/10 cursor-pointer transition-all"><Gamepad2 size={14} /></span>
          </div>
          <p className="text-center text-[10px] text-gray-700 mt-4">© 2024 عرب هاك - CCRAFT SPACE • جميع الحقوق محفوظة</p>
        </div>
      </footer>
    </div>
  );
}

// ============ REUSABLE COMPONENTS ============

function SectionTitle({ icon, title }: { icon: React.ReactNode; title: string }) {
  return (
    <div className="flex items-center gap-2 mb-3 mt-6">
      <span className="text-purple-400">{icon}</span>
      <h3 className="text-sm font-bold text-purple-200">{title}</h3>
      <div className="flex-1 h-px bg-gradient-to-l from-purple-500/20 to-transparent" />
    </div>
  );
}

const colorMap: Record<string, { bg: string; border: string; icon: string; hover: string }> = {
  purple: { bg: "bg-purple-500/15", border: "border-purple-500/25", icon: "text-purple-400", hover: "hover:bg-purple-500/25" },
  blue: { bg: "bg-blue-500/15", border: "border-blue-500/25", icon: "text-blue-400", hover: "hover:bg-blue-500/25" },
  cyan: { bg: "bg-cyan-500/15", border: "border-cyan-500/25", icon: "text-cyan-400", hover: "hover:bg-cyan-500/25" },
  green: { bg: "bg-green-500/15", border: "border-green-500/25", icon: "text-green-400", hover: "hover:bg-green-500/25" },
  sky: { bg: "bg-sky-500/15", border: "border-sky-500/25", icon: "text-sky-400", hover: "hover:bg-sky-500/25" },
  pink: { bg: "bg-pink-500/15", border: "border-pink-500/25", icon: "text-pink-400", hover: "hover:bg-pink-500/25" },
  amber: { bg: "bg-amber-500/15", border: "border-amber-500/25", icon: "text-amber-400", hover: "hover:bg-amber-500/25" },
  orange: { bg: "bg-orange-500/15", border: "border-orange-500/25", icon: "text-orange-400", hover: "hover:bg-orange-500/25" },
  violet: { bg: "bg-violet-500/15", border: "border-violet-500/25", icon: "text-violet-400", hover: "hover:bg-violet-500/25" },
  indigo: { bg: "bg-indigo-500/15", border: "border-indigo-500/25", icon: "text-indigo-400", hover: "hover:bg-indigo-500/25" },
  yellow: { bg: "bg-yellow-500/15", border: "border-yellow-500/25", icon: "text-yellow-400", hover: "hover:bg-yellow-500/25" },
  rose: { bg: "bg-rose-500/15", border: "border-rose-500/25", icon: "text-rose-400", hover: "hover:bg-rose-500/25" },
  teal: { bg: "bg-teal-500/15", border: "border-teal-500/25", icon: "text-teal-400", hover: "hover:bg-teal-500/25" },
};

function CategoryCard({ icon, label, color, badge, subtitle, onClick }: {
  icon: React.ReactNode; label: string; color: string; badge?: string; subtitle?: string; onClick?: () => void;
}) {
  const c = colorMap[color] || colorMap.purple;
  return (
    <button onClick={onClick}
      className={`relative ${c.bg} ${c.hover} ${c.border} border rounded-2xl p-4 text-center transition-all hover:scale-[1.03] active:scale-95 group`}
    >
      {badge && <span className="absolute -top-2 -right-2 bg-green-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">{badge}</span>}
      <div className={`${c.icon} mb-2 flex justify-center group-hover:scale-110 transition-transform`}>{icon}</div>
      <p className="text-sm font-medium">{label}</p>
      {subtitle && <p className="text-[10px] text-gray-500 mt-0.5">{subtitle}</p>}
    </button>
  );
}

function QuickAction({ icon, label, color, subtitle, onClick }: {
  icon: React.ReactNode; label: string; color: string; subtitle?: string; onClick?: () => void;
}) {
  const c = colorMap[color] || colorMap.purple;
  return (
    <button onClick={onClick}
      className={`w-full flex items-center gap-4 ${c.bg} ${c.hover} ${c.border} border rounded-xl p-3 transition-all group`}
    >
      <div className={`${c.icon} group-hover:scale-110 transition-transform`}>{icon}</div>
      <div className="flex-1 text-right">
        <p className="text-sm font-medium">{label}</p>
        {subtitle && <p className="text-xs text-gray-500">{subtitle}</p>}
      </div>
      <ChevronLeft size={16} className="text-gray-600" />
    </button>
  );
}

function StatCard({ label, value, icon, color }: { label: string; value: number; icon: React.ReactNode; color: string }) {
  const c = colorMap[color] || colorMap.purple;
  return (
    <div className={`${c.bg} ${c.border} border rounded-xl p-4 text-center`}>
      <div className={`${c.icon} mb-2 flex justify-center`}>{icon}</div>
      <p className="text-xl font-bold">{typeof value === "number" ? value.toLocaleString() : value}</p>
      <p className="text-xs text-gray-400 mt-1">{label}</p>
    </div>
  );
}

function Modal({ children, onClose, title }: { children: React.ReactNode; onClose: () => void; title: string }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-[#111128] border border-purple-900/30 rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="flex items-center justify-between p-4 border-b border-purple-900/20">
          <button onClick={onClose} className="bg-white/10 hover:bg-white/20 p-2 rounded-lg transition-all"><X size={18} /></button>
          <h3 className="font-bold text-lg">{title}</h3>
          <div className="w-9" />
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}
