import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "عرب هاك - CCRAFT SPACE",
  description: "منصة سكربتات ROBLOX العربية - Arab Hack",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-[#0a0a1a] text-white antialiased min-h-screen">{children}</body>
    </html>
  );
}
