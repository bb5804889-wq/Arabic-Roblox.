import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { chatMessages } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const messages = await db.select().from(chatMessages).orderBy(desc(chatMessages.createdAt)).limit(50);
    return NextResponse.json(messages.reverse());
  } catch {
    return NextResponse.json([]);
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { message } = body;

    if (!message || typeof message !== "string") {
      return NextResponse.json({ error: "الرسالة مطلوبة" }, { status: 400 });
    }

    // Save user message
    await db.insert(chatMessages).values({
      role: "user",
      content: message,
    });

    // Get API key from settings
    const { apiSettings } = await import("@/db/schema");
    const settings = await db.select().from(apiSettings).limit(1);
    const apiKey = settings[0]?.novaAiApiKey || settings[0]?.siteApiKey;

    let assistantReply = "";

    if (apiKey) {
      try {
        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:generateContent?key=${apiKey}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              contents: [{ parts: [{ text: message }] }],
              generationConfig: { maxOutputTokens: 1024 },
            }),
          }
        );
        const data = await response.json();
        assistantReply = data.candidates?.[0]?.content?.parts?.[0]?.text || "عذراً، لم أتمكن من توليد رد.";
      } catch {
        assistantReply = "عذراً، حدث خطأ في الاتصال بالذكاء الاصطناعي. تأكد من صحة مفتاح API.";
      }
    } else {
      assistantReply = `مرحباً! أنا NOVA AI، مساعدك الذكي. ⚡\n\nللحصول على ردود ذكية، يرجى إعداد مفتاح API من قسم إعدادات API.\n\nمفتاح Gemini مطلوب لتفعيل الذكاء الاصطناعي.\n\nيمكنني مساعدتك في:\n• كتابة سكربتات Roblox\n• حل مشاكل الأكواد\n• شرح المفاهيم البرمجية\n• اقتراح أفكار للألعاب`;
    }

    // Save assistant message
    await db.insert(chatMessages).values({
      role: "assistant",
      content: assistantReply,
    });

    return NextResponse.json({ role: "assistant", content: assistantReply });
  } catch {
    return NextResponse.json({ error: "Database error" }, { status: 500 });
  }
}
