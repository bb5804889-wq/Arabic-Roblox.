import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { scripts } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const category = url.searchParams.get("category");
    const featured = url.searchParams.get("featured");

    let result;
    if (featured === "true") {
      result = await db.select().from(scripts).where(eq(scripts.featured, true)).orderBy(desc(scripts.createdAt)).limit(10);
    } else if (category) {
      result = await db.select().from(scripts).where(eq(scripts.category, category)).orderBy(desc(scripts.createdAt)).limit(20);
    } else {
      result = await db.select().from(scripts).orderBy(desc(scripts.createdAt)).limit(20);
    }

    // If no scripts in DB, return some default ones
    if (result.length === 0) {
      return NextResponse.json(getDefaultScripts(featured === "true"));
    }

    return NextResponse.json(result);
  } catch {
    return NextResponse.json(getDefaultScripts(false));
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { title, description, code, category, author } = body;

    if (!title) {
      return NextResponse.json({ error: "العنوان مطلوب" }, { status: 400 });
    }

    const result = await db.insert(scripts).values({
      title,
      description: description || "",
      code: code || "",
      category: category || "general",
      author: author || "مجهول",
    }).returning();

    return NextResponse.json(result[0]);
  } catch {
    return NextResponse.json({ error: "Database error" }, { status: 500 });
  }
}

function getDefaultScripts(featuredOnly: boolean) {
  const all = [
    { id: "1", title: "سكربت سرعة خارقة", description: "زيادة سرعة اللاعب في أي لعبة Roblox", code: 'game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 100', category: "roblox", author: "عرب هاك", featured: true, downloads: 1520, createdAt: new Date().toISOString() },
    { id: "2", title: "سكربت طيران لا محدود", description: "تفعيل الطيران في لعبة Roblox", code: 'loadstring(game:HttpGet("fly_script"))()', category: "roblox", author: "عرب هاك", featured: true, downloads: 2340, createdAt: new Date().toISOString() },
    { id: "3", title: "سكربت ESP وول هاك", description: "رؤية جميع اللاعبين عبر الجدران", code: '-- ESP Wall Hack Script', category: "roblox", author: "عرب هاك", featured: false, downloads: 890, createdAt: new Date().toISOString() },
    { id: "4", title: "سكربت أموال لا محدود", description: "سكربت لإعطاء أموال لا محدودة في الألعاب المدعومة", code: '-- Infinite Money Script', category: "roblox", author: "عرب هاك", featured: true, downloads: 3500, createdAt: new Date().toISOString() },
    { id: "5", title: "سكربت تيليبورتر", description: "الانتقال الفوري لأي مكان في الخريطة", code: '-- Teleporter Script', category: "roblox", author: "عرب هاك", featured: false, downloads: 670, createdAt: new Date().toISOString() },
    { id: "6", title: "سكربت حماية أكونت", description: "حماية حسابك من السرقة والاختراق", code: '-- Account Protection Script', category: "security", author: "عرب هاك", featured: false, downloads: 1200, createdAt: new Date().toISOString() },
  ];
  if (featuredOnly) return all.filter(s => s.featured);
  return all;
}
