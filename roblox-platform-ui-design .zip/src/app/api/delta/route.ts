import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { apiSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

// Key expiry duration: 24 hours
const KEY_EXPIRY_MS = 24 * 60 * 60 * 1000;

export async function GET() {
  try {
    const settings = await db.select().from(apiSettings).limit(1);
    const s = settings[0];

    if (!s) {
      return NextResponse.json({ hasKey: false, message: "لم يتم إعداد النظام بعد" });
    }

    const now = new Date();
    const keyValid = s.deltaCachedKey && s.deltaKeyExpiry && new Date(s.deltaKeyExpiry) > now;

    if (keyValid) {
      const remainingMs = new Date(s.deltaKeyExpiry!).getTime() - now.getTime();
      const remainingHours = Math.floor(remainingMs / (60 * 60 * 1000));
      const remainingMinutes = Math.floor((remainingMs % (60 * 60 * 1000)) / (60 * 1000));

      return NextResponse.json({
        hasKey: true,
        key: s.deltaCachedKey,
        expiresAt: s.deltaKeyExpiry,
        remainingTime: `${remainingHours} ساعة ${remainingMinutes} دقيقة`,
        sourceUrl: s.deltaAuthUrl ? s.deltaAuthUrl.substring(0, 50) + "..." : null,
      });
    }

    // Key expired or missing — try to fetch a new one
    if (s.deltaAuthUrl) {
      const freshKey = await fetchDeltaKey(s.deltaAuthUrl);
      if (freshKey) {
        // Cache the new key
        const expiry = new Date(Date.now() + KEY_EXPIRY_MS);
        await db.update(apiSettings).set({
          deltaCachedKey: freshKey,
          deltaKeyExpiry: expiry,
        }).where(eq(apiSettings.id, s.id));

        return NextResponse.json({
          hasKey: true,
          key: freshKey,
          expiresAt: expiry.toISOString(),
          remainingTime: "24 ساعة 0 دقيقة",
          sourceUrl: s.deltaAuthUrl.substring(0, 50) + "...",
          refreshed: true,
        });
      }

      return NextResponse.json({
        hasKey: false,
        message: "لم نتمكن من جلب مفتاح جديد. حاول مرة أخرى لاحقاً.",
        sourceUrl: s.deltaAuthUrl.substring(0, 50) + "...",
      });
    }

    return NextResponse.json({
      hasKey: false,
      message: "لم يتم إعداد رابط مفتاح Delta بعد. اذهب لإعدادات API وضع الرابط.",
    });
  } catch (err) {
    return NextResponse.json({ hasKey: false, message: "خطأ في الخادم: " + String(err) }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { platform } = body; // ios, android, windows

    if (platform && !["ios", "android", "windows"].includes(platform)) {
      return NextResponse.json({ error: "المنصة غير صحيحة. اختر: ios, android, windows" }, { status: 400 });
    }

    // Get settings and delta key
    const settings = await db.select().from(apiSettings).limit(1);
    const s = settings[0];

    if (!s?.deltaAuthUrl) {
      return NextResponse.json({
        error: "لم يتم إعداد رابط مفتاح Delta بعد. قم بإعداد API أولاً.",
        requiresSetup: true,
      }, { status: 400 });
    }

    // Check cached key or fetch new one
    const now = new Date();
    const keyValid = s.deltaCachedKey && s.deltaKeyExpiry && new Date(s.deltaKeyExpiry) > now;
    let deltaKey = s.deltaCachedKey;

    if (!keyValid) {
      const freshKey = await fetchDeltaKey(s.deltaAuthUrl);
      if (freshKey) {
        deltaKey = freshKey;
        const expiry = new Date(Date.now() + KEY_EXPIRY_MS);
        await db.update(apiSettings).set({
          deltaCachedKey: freshKey,
          deltaKeyExpiry: expiry,
        }).where(eq(apiSettings.id, s.id));
      } else {
        return NextResponse.json({
          error: "لم نتمكن من جلب مفتاح Delta. حاول مرة أخرى لاحقاً.",
          deltaKey: null,
        }, { status: 503 });
      }
    }

    // Return download info with the key
    const platformInfo: Record<string, { version: string; downloadUrl: string; size: string; changelog: string }> = {
      ios: {
        version: "2.8.5",
        downloadUrl: "https://delta.com/download/ios",
        size: "45 MB",
        changelog: "إصلاح أخطاء وتحسين الأداء على iOS 18",
      },
      android: {
        version: "2.8.3",
        downloadUrl: "https://delta.com/download/android",
        size: "38 MB",
        changelog: "دعم Android 15 وتحسين السرعة",
      },
      windows: {
        version: "2.8.6",
        downloadUrl: "https://delta.com/download/windows",
        size: "52 MB",
        changelog: "دعم Windows 11 وتحسين الحقن",
      },
    };

    const info = platform ? platformInfo[platform] : platformInfo.windows;

    return NextResponse.json({
      success: true,
      platform: platform || "windows",
      ...info,
      name: "Delta Hack",
      deltaKey,
      message: `أحدث نسخة من هاك دلتا لمنصة ${platform || "windows"}`,
    });
  } catch {
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 });
  }
}

/**
 * Fetch a Delta key from the platorelay auth URL.
 * The URL format is: https://auth.platorelay.com/a?d=<encoded_data>
 * It returns a key that starts with FREE_ followed by a hash.
 */
async function fetchDeltaKey(authUrl: string): Promise<string | null> {
  try {
    const response = await fetch(authUrl, {
      method: "GET",
      headers: {
        "User-Agent": "ArabHack/1.0",
        "Accept": "text/plain, */*",
      },
      redirect: "follow",
      signal: AbortSignal.timeout(15000), // 15s timeout
    });

    if (!response.ok) {
      console.error(`Delta auth failed: ${response.status} ${response.statusText}`);
      return null;
    }

    const text = await response.text();

    // The key typically starts with "FREE_" followed by a hash
    // Try to find it in the response
    const freeKeyMatch = text.match(/FREE_[a-f0-9]{32,}/i);
    if (freeKeyMatch) {
      return freeKeyMatch[0];
    }

    // If the response is a redirect URL that contains the key
    const urlKeyMatch = text.match(/key=([A-Za-z0-9_]+)/);
    if (urlKeyMatch) {
      return urlKeyMatch[1];
    }

    // If the entire response looks like a key
    const trimmed = text.trim();
    if (trimmed.startsWith("FREE_") || /^[a-zA-Z0-9_]{20,}$/.test(trimmed)) {
      return trimmed;
    }

    // Try parsing as JSON
    try {
      const json = JSON.parse(text);
      const key = json.key || json.token || json.auth_key || json.deltaKey;
      if (key && typeof key === "string") {
        return key;
      }
    } catch {
      // Not JSON
    }

    // Return the raw text as a last resort if it looks like a key
    if (trimmed.length >= 20 && trimmed.length <= 200) {
      return trimmed;
    }

    console.error("Could not parse Delta key from response:", text.substring(0, 200));
    return null;
  } catch (err) {
    console.error("Delta key fetch error:", err);
    return null;
  }
}
