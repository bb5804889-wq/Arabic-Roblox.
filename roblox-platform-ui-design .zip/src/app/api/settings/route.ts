import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { apiSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

const API_PASSWORD = "AH-7392-XQ";

export async function GET() {
  try {
    const settings = await db.select().from(apiSettings).limit(1);
    if (settings.length === 0) {
      return NextResponse.json({ siteApiKey: null, novaAiApiKey: null, deltaAuthUrl: null, deltaCachedKey: null });
    }
    const s = settings[0];
    // Check if cached delta key is still valid (not expired)
    const now = new Date();
    const keyValid = s.deltaKeyExpiry && new Date(s.deltaKeyExpiry) > now;
    return NextResponse.json({
      siteApiKey: s.siteApiKey ? "••••••••" : null,
      novaAiApiKey: s.novaAiApiKey ? "••••••••" : null,
      deltaAuthUrl: s.deltaAuthUrl || null,
      deltaCachedKey: keyValid ? s.deltaCachedKey : null,
      deltaKeyExpiry: keyValid ? s.deltaKeyExpiry : null,
      hasKeys: !!(s.siteApiKey || s.novaAiApiKey),
    });
  } catch {
    return NextResponse.json({ siteApiKey: null, novaAiApiKey: null, deltaAuthUrl: null, deltaCachedKey: null });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { password, siteApiKey, novaAiApiKey, deltaAuthUrl } = body;

    if (password !== API_PASSWORD) {
      return NextResponse.json({ error: "كلمة السر غير صحيحة" }, { status: 403 });
    }

    const existing = await db.select().from(apiSettings).limit(1);

    if (existing.length > 0) {
      const updateData: Record<string, string | null | Date | undefined> = {};
      if (siteApiKey !== undefined) updateData.siteApiKey = siteApiKey;
      if (novaAiApiKey !== undefined) updateData.novaAiApiKey = novaAiApiKey;
      if (deltaAuthUrl !== undefined) updateData.deltaAuthUrl = deltaAuthUrl;
      // When auth URL changes, invalidate cached key
      if (deltaAuthUrl !== undefined) {
        updateData.deltaCachedKey = null;
        updateData.deltaKeyExpiry = null;
      }

      await db.update(apiSettings).set(updateData).where(eq(apiSettings.id, existing[0].id));
    } else {
      await db.insert(apiSettings).values({
        siteApiKey: siteApiKey || null,
        novaAiApiKey: novaAiApiKey || null,
        deltaAuthUrl: deltaAuthUrl || null,
      });
    }

    return NextResponse.json({ success: true, message: "تم حفظ إعدادات API بنجاح" });
  } catch {
    return NextResponse.json({ error: "Database error" }, { status: 500 });
  }
}
